<?php

namespace App\Services;

interface BaseServiceInterface {
    public function run();
}